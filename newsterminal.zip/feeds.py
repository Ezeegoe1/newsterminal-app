# Sources RSS gratuites. (nom, url, catégorie, intervalle_s)
G = "https://news.google.com/rss/search?q={q}+when:{w}&hl={hl}&gl={gl}&ceid={gl}:{lang}"
BS = "https://public.api.bsky.app/xrpc/app.bsky.feed.getAuthorFeed?actor={}&limit=30&filter=posts_no_replies"
def gnews(q, hl="en-US", gl="US", lang="en", w="1h"):
    return G.format(q=q, hl=hl, gl=gl, lang=lang, w=w)

FEEDS = [
    # --- Banques centrales / stats officielles (sources primaires) ---
    ("FED",        "https://www.federalreserve.gov/feeds/press_all.xml",   "CB",     30),
    ("ECB",        "https://www.ecb.europa.eu/rss/press.html",             "CB",     30),
    ("BoE",        "https://www.bankofengland.co.uk/rss/news",             "CB",     60),
    ("GN Macro",   gnews("CPI+OR+payrolls+OR+%22jobs+report%22+OR+PCE+OR+GDP"), "MACRO", 45),
    # --- Squawk / temps réel ---
    ("investingLive", "https://investinglive.com/feed",                    "SQUAWK", 20),
    ("Investing",  "https://www.investing.com/rss/news_25.rss",            "SQUAWK", 30),
    ("FinancialJuice", "https://www.financialjuice.com/feed.ashx?xy=rss",   "SQUAWK", 10),
    # Bluesky (API publique gratuite) : comptes de « squawk » marchés
    ("Unusual Whales", "https://public.api.bsky.app/xrpc/app.bsky.feed.getAuthorFeed?actor=unusualwhales.bsky.social&limit=30&filter=posts_no_replies", "SQUAWK", 30),
    # Comptes « flash » vérifiés actifs (Bluesky). X/Twitter n'a plus d'accès gratuit : ces comptes publient les mêmes infos.
    ("Reuters",       BS.format("reuters.com"),            "SQUAWK", 30),
    ("Watcher Guru",  BS.format("watcher.guru"),           "SQUAWK", 30),
    ("Axios",         BS.format("axios.com"),              "US",     45),
    ("Nick Timiraos", BS.format("nicktimiraos.bsky.social"), "CB",   60),   # journaliste WSJ, « porte-voix » officieux de la Fed
    ("Carl Quintanilla", BS.format("carlquintanilla.bsky.social"), "US", 45),  # CNBC Squawk on the Street
    ("El-Erian",      BS.format("elerianm.bsky.social"),   "MACRO",  90),
    ("CNBC Bsky",     BS.format("cnbc.com"),               "US",     45),
    ("WSJ",           BS.format("wsj.com"),                "US",     60),
    ("FT",            BS.format("financialtimes.com"),     "GLOBAL", 60),
    ("Whale Alert",   BS.format("whale-alert.io"),         "CRYPTO", 60),   # gros transferts (≥ 100 M$ seulement)
    ("Fed discours",  "https://www.federalreserve.gov/feeds/speeches.xml", "CB", 60),
    ("Investing Éco", "https://www.investing.com/rss/news_95.rss",  "MACRO",  30),
    ("Investing FX",  "https://www.investing.com/rss/news_1.rss",   "SQUAWK", 30),
    # --- Matières premières ---
    ("Investing MP",  "https://www.investing.com/rss/commodities.rss", "COMMO", 45),
    ("Kitco",         gnews("site:kitco.com", w="1d"),       "COMMO",  60),
    ("OilPrice",      gnews("site:oilprice.com", w="1d"),    "COMMO",  60),
    ("GN OPEP",       gnews("OPEC+OR+crude+OR+brent+OR+%22gold+price%22+OR+copper"), "COMMO", 60),
    # --- Agences / médias US ---
    ("Bloomberg",  "https://www.bloomberg.com/feeds/markets/news.rss",         "US",   30),
    ("CNBC",       "https://search.cnbc.com/rs/search/combinedcms/view.xml?partnerId=wrss01&id=100003114", "US", 30),
    ("MarketWatch","https://feeds.content.dowjones.io/public/rss/mw_topstories", "US", 45),
    ("WSJ Mkts",   "https://feeds.content.dowjones.io/public/rss/RSSMarketsMain", "US", 45),
    ("FT Mkts",    "https://www.ft.com/markets?format=rss",                "GLOBAL",   60),
    ("Yahoo Fin",  "https://feeds.finance.yahoo.com/rss/2.0/headline?s=%5EGSPC,%5EIXIC,CL%3DF,GC%3DF&region=US&lang=en-US",              "US",   60),
    # --- Europe / Asie ---
    ("Nikkei Asia","https://asia.nikkei.com/rss/feed/nar",                 "ASIA",   60),
    # --- Afrique ---
    ("GN ZA",      gnews("JSE+OR+rand+OR+SARB+OR+Eskom", "en-ZA", "ZA", "en", w="1d"), "AFRIQUE", 90),
    ("GN NG",      gnews("naira+OR+CBN+OR+NGX+OR+Nigeria+economy", "en-NG", "NG", "en", w="1d"), "AFRIQUE", 90),
    ("GN Afr EN",  gnews("Africa+markets+OR+Egypt+pound+OR+Kenya+shilling+OR+Afreximbank", w="1d"), "AFRIQUE", 90),
    ("GN Afr FR",  gnews("BRVM+OR+BCEAO+OR+UEMOA+OR+franc+CFA+OR+BEAC", "fr", "SN", "fr", w="1d"), "AFRIQUE", 120),
    ("GN Maroc",   gnews("Bourse+de+Casablanca+OR+Bank+Al-Maghrib+OR+dirham", "fr", "MA", "fr", w="1d"), "AFRIQUE", 120),
    # --- Crypto ---
    ("CoinDesk",   "https://www.coindesk.com/arc/outboundfeeds/rss/",      "CRYPTO", 60),
    ("Investing Crypto", "https://www.investing.com/rss/news_301.rss",     "CRYPTO", 30),
    ("The Block",  gnews("site:theblock.co", w="1d"),                      "CRYPTO", 60),
    ("Decrypt",    gnews("site:decrypt.co", w="1d"),                       "CRYPTO", 60),
    # --- Analyses de marché rapides ---
    ("FXStreet",   gnews("site:fxstreet.com", w="1d"),                     "SQUAWK", 45),
    ("ZeroHedge",  gnews("site:zerohedge.com", w="1d"),                    "US",     60),
    ("Zonebourse", gnews("site:zonebourse.com/actualite-bourse", "fr", "FR", "fr", w="1d"), "EU",     60),
    ("Les Echos",  gnews("site:lesechos.fr+(bourse+OR+march%C3%A9s+OR+CAC+OR+BCE)", "fr", "FR", "fr", w="1d"), "EU", 60),
    ("Boursorama", gnews("site:boursorama.com/bourse/actualites", "fr", "FR", "fr", w="1d"), "EU",     60),
    # --- Google News : agrège Reuters, AP, etc. dans plusieurs langues ---
    ("GN US",      gnews("stock+market+OR+fed+OR+inflation+OR+treasury"),  "US",    60),
    ("GN Geo",     gnews("tariffs+OR+sanctions+OR+OPEC+OR+war+oil"),       "GLOBAL",    60),
    ("GN FR",      gnews("bourse+OR+BCE+OR+inflation", "fr", "FR", "fr"),  "EU",     90),
    ("GN DE",      gnews("Börse+OR+EZB+OR+DAX", "de", "DE", "de"),         "EU",     90),
    ("GN JP",      gnews("日銀+OR+日経平均+OR+為替", "ja", "JP", "ja", w="1d"),      "ASIA",   90),
    ("GN CN",      gnews("央行+OR+股市+OR+人民币", "zh-CN", "CN", "zh-Hans", w="1d"), "ASIA",   90),
]

# Mots-clés à fort impact -> alerte (score additionné)
IMPACT = {
    5: ["breaking", "flash", "emergency", "rate decision", "rate cut", "rate hike", "fomc",
        "nonfarm", "payrolls", "cpi", "pce", "default", "bankruptcy", "halted", "circuit breaker",
        "invasion", "missile", "coup", "intervention", "powell", "lagarde", "ueda"],
    3: ["tariff", "sanction", "opec", "gdp", "pmi", "ism", "unemployment", "jobless claims",
        "inflation", "yield", "treasury", "downgrade", "upgrade", "guidance", "earnings",
        "war", "ceasefire", "nuclear", "strike", "trump", "xi jinping", "sec ", "etf", "bce", "fed",
        "taux", "zinsen", "利上げ", "降息",
        "crash", "plunge", "rout", "sell-off", "selloff", "tumble", "slump", "soar", "record high", "meltdown",
        "krach", "s'effondre", "plonge", "chute", "absturz", "暴落", "急落", "暴跌", "recession", "récession", "bailout"],
    1: ["oil", "gold", "dollar", "euro", "yen", "bitcoin", "s&p", "nasdaq", "dow", "dax", "cac", "nikkei", "hang seng", "stocks", "shares", "futures", "bourse", "aktien",
        "rally", "baisse", "hausse", "株", "股", "forex", "bond", "obligataire", "brent", "wti", "copper"],
}
ALERT_THRESHOLD = 5

# Langue de chaque source (par défaut : anglais)
LANG = {"Zonebourse": "fr", "Les Echos": "fr", "Boursorama": "fr", "GN FR": "fr", "GN Afr FR": "fr", "GN Maroc": "fr", "GN DE": "de", "GN JP": "ja", "GN CN": "zh"}
