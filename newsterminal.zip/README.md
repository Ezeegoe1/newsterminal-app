# News Terminal
```
pip install -r requirements.txt
python server.py        # http://localhost:8765
```
Alertes Telegram (optionnel) : `TG_TOKEN=xxx TG_CHAT=yyy python server.py`
Sources / mots-clés / seuil d'alerte : `feeds.py`
