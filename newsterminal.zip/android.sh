#!/data/data/com.termux/files/usr/bin/bash
# Lancement sur Android (Termux). Premier lancement : installe tout automatiquement.
cd "$(dirname "$0")"
if ! command -v python >/dev/null; then pkg update -y && pkg install -y python termux-api; fi
python -c "import feedparser, certifi" 2>/dev/null || pip install -q -r requirements.txt
termux-wake-lock 2>/dev/null   # empêche Android de couper le serveur écran éteint
(sleep 5 && termux-open-url http://localhost:8765) &
python server.py
