#!/usr/bin/env python3
"""Terminal de news finance temps réel. Usage: python server.py  -> http://localhost:8765"""
import base64, shutil, subprocess, calendar, json, urllib.parse, urllib.error, os, queue, re, sqlite3, threading, time, hashlib, html, urllib.request
from concurrent.futures import ThreadPoolExecutor
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
import ssl
try:  # macOS : Python sans certificats -> on utilise ceux de certifi
    import certifi
    ssl._create_default_https_context = lambda: ssl.create_default_context(cafile=certifi.where())
except ImportError: pass
import feedparser
from feeds import FEEDS, IMPACT, ALERT_THRESHOLD, LANG

PORT = int(os.environ.get("PORT", 8765))
DB = os.path.join(os.path.dirname(__file__), "news_v3.db")
PASSWORD = os.environ.get("TERMINAL_PASSWORD")
TG_TOKEN, TG_CHAT = os.environ.get("TG_TOKEN"), os.environ.get("TG_CHAT")
UA = "Mozilla/5.0 (NewsTerminal)"

db = sqlite3.connect(DB, check_same_thread=False)
db.execute("CREATE TABLE IF NOT EXISTS news(id TEXT PRIMARY KEY, ts REAL, seen REAL, src TEXT, cat TEXT, title TEXT, link TEXT, score INT, feed TEXT)")
lock = threading.Lock()
clients: list[queue.Queue] = []
state = {}  # url -> etag/modified/last_ok/err

JUNK = re.compile(r"price today|live gold price|cours action|cotation bourse|graphique d.analyse|charts and news|transcript|live chart|spot chart|price chart|stock price|cours et graphique|^top \d|^(news|markets|crypto|prediction markets)$|\| .*\|", re.I)
def norm(t): return re.sub(r"\W+", " ", t.lower()).strip()

def score(title):
    t = " " + title.lower() + " "
    return sum(w for w, kws in IMPACT.items() for k in kws if k in t)

def why(title):
    """Mots-clés qui ont déclenché le score, ex. « cpi +5, fed +3 »."""
    t = " " + title.lower() + " "; m = sorted({(w, k.strip()) for w, kws in IMPACT.items() if w >= 3 for k in kws if k in t}, reverse=True)
    return ", ".join(f"{k} +{w}" for w, k in m[:4])

def telegram(item):
    if not (TG_TOKEN and TG_CHAT): return
    try:
        data = json.dumps({"chat_id": TG_CHAT, "text": f"🚨 [{item['src']}] {item['title']}\n{item['link']}"}).encode()
        urllib.request.urlopen(urllib.request.Request(f"https://api.telegram.org/bot{TG_TOKEN}/sendMessage",
                               data, {"Content-Type": "application/json"}), timeout=5)
    except Exception: pass

def android_notify(item):
    # Termux (Android) : notification native si termux-api est installé
    if shutil.which("termux-notification"):
        try:
            subprocess.Popen(["termux-notification", "--title", f"🚨 {item['src']}", "--content", item["title"],
                              "--action", f"termux-open-url '{item['link']}'", "--priority", "high", "--sound",
                              "--id", item["id"][:8]], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        except Exception: pass

def broadcast(item):
    for q in list(clients): q.put(item)

def poll(feed, first):
    name, url, cat, _ = feed
    st = state.setdefault(url, {})
    try:
        if "bsky.app/xrpc" in url:   # Bluesky : API JSON publique
            j = json.loads(urllib.request.urlopen(urllib.request.Request(url, headers={"User-Agent": UA}), timeout=15).read())
            ents = []
            for x in j.get("feed", []):
                p = x.get("post", {}); r = p.get("record", {}); txt = (r.get("text") or "").strip()
                if not txt or x.get("reason"): continue   # pas de reposts
                h = (p.get("author") or {}).get("handle", ""); rk = p.get("uri", "").rsplit("/", 1)[-1]
                if "whale-alert" in h:   # seulement les très gros transferts (≥ 100 M$)
                    m_ = re.search(r"\(([\d,]+) USD\)", txt)
                    if not m_ or int(m_.group(1).replace(",", "")) < 100_000_000: continue
                txt = re.sub(r"https?://\S+|\b\S+\.(com|io|app|ly|co)/\S*", "", txt)   # pas de liens dans le titre
                lines = [l.strip() for l in txt.split("\n") if len(re.findall(r"[A-Za-zÀ-ÿ]", l)) >= 3]   # saute les lignes d'emojis
                if not lines: continue
                ents.append({"title": " ".join(lines[:2])[:220], "link": f"https://bsky.app/profile/{h}/post/{rk}",
                             "published_parsed": time.strptime(r.get("createdAt", "")[:19], "%Y-%m-%dT%H:%M:%S") if r.get("createdAt") else None})
            d = feedparser.FeedParserDict(entries=[feedparser.FeedParserDict(e) for e in ents], status=200)
        else:
            d = feedparser.parse(url, etag=st.get("etag"), modified=st.get("modified"), agent=UA)
        if d.get("status") == 304:
            st.update(last=time.time(), err=None); return
        if not d.entries and "news.google.com" in url:   # aucun article récent : pas une panne
            st.update(last=time.time(), err=None, n=0); return
        if not d.entries:
            st.update(last=time.time(), err=f"0 article (HTTP {d.get('status','?')}): {str(d.get('bozo_exception',''))[:100]}"); return
        st.update(etag=d.get("etag"), modified=d.get("modified"), last=time.time(), err=None, n=len(d.entries))
        for e in d.entries[:50]:
            title = html.unescape(re.sub("<[^>]+>", "", e.get("title", ""))).strip()
            if not title: continue
            title = re.sub(r"^FinancialJuice:\s*", "", title)
            src = name
            if "news.google.com" in url and " - " in title:
                title, _, pub = title.rpartition(" - ")
                if name.startswith("GN"): src = pub.strip()
                if len(title.split()) < 5 or JUNK.search(title): continue   # pages de cours, sommaires, transcriptions
            title = re.sub(r"^[^\w$(«\"']+", "", title).strip()          # emojis en tête (🚨 🚨 …)
            if not title: continue
            hid = hashlib.md5(norm(title)[:120].encode()).hexdigest()  # dédup inter-sources
            pp = e.get("published_parsed") or e.get("updated_parsed")
            ts = calendar.timegm(pp) if pp else (time.time() - 86400 if first else time.time())  # sans date: en bas au 1er chargement
            item = dict(id=hid, ts=ts, seen=time.time(), src=src, cat=cat, title=title,
                        link=e.get("link", ""), score=score(title), feed=name)
            with lock:
                cur = db.execute("INSERT OR IGNORE INTO news VALUES(:id,:ts,:seen,:src,:cat,:title,:link,:score,:feed)", item)
                db.commit()
            if cur.rowcount and not first and time.time() - ts < 3600:
                item["new"] = True; item["why"] = why(title)
                broadcast(item)
                if item["score"] >= ALERT_THRESHOLD: telegram(item); android_notify(item)
    except Exception as ex:
        st["err"] = str(ex)[:120]

def report():
    time.sleep(20)
    with lock: n = db.execute("SELECT COUNT(*) FROM news").fetchone()[0]
    print(f"\n=== {n} news en base ===")
    for f in FEEDS:
        st = state.get(f[1], {})
        print(f"  {'OK ' if st.get('n') else 'ERR'} {f[0]:14} {st.get('n', 0):3} articles  {st.get('err') or ''}")
    print(flush=True)

# ---- Calendrier (macro Nasdaq + semaine ForexFactory + résultats Nasdaq) ----
CAL = {"ts": 0}
def cal_urls():
    from datetime import datetime, timedelta
    try:
        from zoneinfo import ZoneInfo; now = datetime.now(ZoneInfo("America/New_York"))
    except Exception: now = datetime.utcnow() - timedelta(hours=5)
    days = [(now + timedelta(days=d)).strftime("%Y-%m-%d") for d in (-1, 0, 1)]
    u = {"week": "https://nfs.faireconomy.media/ff_calendar_thisweek.json"}
    for i, d in enumerate(days):
        nxt = (now + timedelta(days=i)).strftime("%Y-%m-%d")  # Nasdaq : date=J+1 renvoie les chiffres du jour J
        u["eco_" + d] = f"https://api.nasdaq.com/api/calendar/economicevents?date={nxt}"
        u["earn_" + d] = f"https://api.nasdaq.com/api/calendar/earnings?date={d}"
    return u

AHEAD = {}
def ahead_poller():  # semaine à venir : macro + résultats pour les 7 prochains jours, toutes les 30 min
    from datetime import datetime, timedelta
    while True:
        try:
            from zoneinfo import ZoneInfo; now = datetime.now(ZoneInfo("America/New_York"))
        except Exception: now = datetime.utcnow() - timedelta(hours=5)
        out = {}
        wd = now.weekday()   # 0 = lundi : jours passés de la semaine en cours + jusqu'au dimanche de la semaine suivante
        for i in list(range(-wd, -1)) + list(range(2, 14 - wd)):
            d = (now + timedelta(days=i)).strftime("%Y-%m-%d"); nxt = (now + timedelta(days=i + 1)).strftime("%Y-%m-%d")
            for k, u in (("eco_" + d, f"https://api.nasdaq.com/api/calendar/economicevents?date={nxt}"), ("earn_" + d, f"https://api.nasdaq.com/api/calendar/earnings?date={d}")):
                try:
                    req = urllib.request.Request(u, headers={"User-Agent": "NewsTerminal/1.0", "Accept": "application/json"})
                    out[k] = json.loads(urllib.request.urlopen(req, timeout=20).read().decode("utf-8"))
                except Exception as ex:
                    out[k] = AHEAD.get(k) or {"error": str(ex)[:100]}
                time.sleep(1)
        AHEAD.clear(); AHEAD.update(out)
        time.sleep(1800)

def keep_actuals(old, new):
    """Un chiffre réel déjà reçu ne disparaît pas si Nasdaq renvoie une version plus ancienne."""
    def key_rows(x):
        occ = {}; out = {}
        for r in ((x or {}).get("data") or {}).get("rows") or []:
            b = r.get("country", "") + "|" + r.get("eventName", "") + "|" + r.get("gmt", ""); i = occ.get(b, 0); occ[b] = i + 1; out[b + "|" + str(i)] = r
        return out
    o = key_rows(old)
    for k, r in key_rows(new).items():
        if not (r.get("actual") or "").replace("&nbsp;", "").strip() and k in o and (o[k].get("actual") or "").replace("&nbsp;", "").strip():
            r["actual"] = o[k]["actual"]

def cal_poller():
    while True:
        out = {}
        for k, u in cal_urls().items():
            try:
                req = urllib.request.Request(u, headers={"User-Agent": "NewsTerminal/1.0", "Accept": "application/json"})
                out[k] = json.loads(urllib.request.urlopen(req, timeout=20).read().decode("utf-8"))
            except Exception as ex:
                out[k] = {"error": str(ex)[:100]}
        for k, v in out.items():  # Nasdaq renvoie parfois une version tronquée ou ancienne : on garde le meilleur
            old = CAL.get(k)
            def n(x): return len(((x or {}).get("data") or {}).get("rows") or []) if isinstance(x, dict) else len(x or [])
            if old and ("error" in v or n(v) < n(old) / 2): out[k] = old; continue
            if old and k.startswith("eco_"): keep_actuals(old, v)
        out["ts"] = time.time(); CAL.clear(); CAL.update(out)
        time.sleep(60 if any(n(v) < 5 for k, v in out.items() if k.startswith('eco_')) else 120)

# ---- Cours en direct (Yahoo Finance, un actif toutes les 6 s) ----
QUOTES = [("^GSPC", "S&P 500"), ("^IXIC", "Nasdaq"), ("^DJI", "Dow Jones"), ("^GDAXI", "DAX"), ("^FCHI", "CAC 40"),
          ("^STOXX50E", "Euro Stoxx 50"), ("^N225", "Nikkei"), ("^HSI", "Hang Seng"), ("EURUSD=X", "EUR/USD"),
          ("JPY=X", "USD/JPY"), ("GC=F", "Or"), ("CL=F", "Pétrole WTI"), ("BZ=F", "Brent"), ("^TNX", "Taux US 10 ans"), ("BTC-USD", "Bitcoin")]
PRICES = {}
def price_poller():
    i = 0
    while True:
        lst = list(QUOTES)
        if not lst: time.sleep(5); continue
        missing = [q for q in lst if q[0] not in PRICES]
        sym, name = missing[0] if missing else lst[i % len(lst)]; i += 1
        try:
            o = oanda_quote(sym, name)
            if o: PRICES[sym] = o; time.sleep(2); continue
        except Exception: pass
        try:
            u = "https://query1.finance.yahoo.com/v8/finance/chart/" + urllib.parse.quote(sym) + "?range=1d&interval=5m"
            d = json.loads(urllib.request.urlopen(urllib.request.Request(u, headers={"User-Agent": "NewsTerminal/1.0"}), timeout=15).read())
            r = d["chart"]["result"][0]; m = r["meta"]
            closes = [c for c in ((r.get("indicators") or {}).get("quote") or [{}])[0].get("close") or [] if c is not None]
            PRICES[sym] = {"sym": sym, "name": name, "price": m.get("regularMarketPrice"), "prev": m.get("chartPreviousClose") or m.get("previousClose"),
                           "time": m.get("regularMarketTime"), "cur": m.get("currency"), "spark": closes[-78:]}
            time.sleep(6)
        except urllib.error.HTTPError as ex:
            if ex.code == 404: PRICES[sym] = {"sym": sym, "name": name, "error": "symbole introuvable"}
            time.sleep(60 if ex.code == 429 else 6)
        except Exception:
            time.sleep(10)

ESURP = {}
def earnings_history(sym):
    """4 derniers trimestres : BPA publié vs consensus (Nasdaq) + réaction du titre sur 2 séances (Yahoo)."""
    c = ESURP.get(sym)
    if c and time.time() - c[0] < 6 * 3600: return c[1]
    r = urllib.request.Request("https://api.nasdaq.com/api/company/" + urllib.parse.quote(sym) + "/earnings-surprise", headers={"User-Agent": "NewsTerminal/1.0", "Accept": "application/json"})
    rows = ((((json.loads(urllib.request.urlopen(r, timeout=20).read()).get("data") or {}).get("earningsSurpriseTable") or {}).get("rows")) or [])
    closes = {}
    try:
        u = "https://query1.finance.yahoo.com/v8/finance/chart/" + urllib.parse.quote(sym) + "?range=2y&interval=1d"
        ch = json.loads(urllib.request.urlopen(urllib.request.Request(u, headers={"User-Agent": "NewsTerminal/1.0"}), timeout=15).read())["chart"]["result"][0]
        import datetime as _dt
        closes = {_dt.datetime.utcfromtimestamp(t).date(): v for t, v in zip(ch["timestamp"], ch["indicators"]["quote"][0]["close"]) if v is not None}
    except Exception: pass
    import datetime as _dt
    days = sorted(closes); out = []
    for x in rows:
        mv = None
        try:
            m, d, y = map(int, x["dateReported"].split("/")); D = _dt.date(y, m, d)
            before = [k for k in days if k < D]; after = [k for k in days if k > D]
            if before and after: mv = round((closes[after[0]] - closes[before[-1]]) / closes[before[-1]] * 100, 2)
        except Exception: pass
        out.append({"q": x.get("fiscalQtrEnd"), "date": x.get("dateReported"), "eps": x.get("eps"), "cons": x.get("consensusForecast"), "surp": x.get("percentageSurprise"), "move": mv})
    ESURP[sym] = (time.time(), out); return out

YSESS = {"t": 0}
def yahoo_crumb(force=False):
    """Session Yahoo (cookie + jeton « crumb »), comme le site et la bibliothèque yfinance."""
    if not force and YSESS.get("crumb") and time.time() - YSESS["t"] < 3600: return YSESS
    import http.cookiejar
    jar = http.cookiejar.CookieJar(); op = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(jar))
    try: op.open(urllib.request.Request("https://fc.yahoo.com/", headers={"User-Agent": "NewsTerminal/1.0"}), timeout=10)
    except Exception: pass   # répond 404 mais dépose le cookie
    crumb = op.open(urllib.request.Request("https://query1.finance.yahoo.com/v1/test/getcrumb", headers={"User-Agent": "NewsTerminal/1.0"}), timeout=10).read().decode().strip()
    if not crumb or "Too Many" in crumb or len(crumb) > 40: raise ValueError("Yahoo indisponible (limite de requêtes)")
    YSESS.update(crumb=crumb, op=op, t=time.time()); return YSESS

def yahoo_company(sym):
    """Actions hors US : cours via le graphique Yahoo (accessible), analystes via quoteSummary si Yahoo l'accepte."""
    q = urllib.parse.quote(sym); out = {"src": "yahoo"}
    try:
        u = f"https://query1.finance.yahoo.com/v8/finance/chart/{q}?range=1y&interval=1d"
        r = json.loads(urllib.request.urlopen(urllib.request.Request(u, headers={"User-Agent": "NewsTerminal/1.0"}), timeout=15).read())["chart"]["result"][0]
        out["chart"] = {"meta": r["meta"], "close": [c for c in r["indicators"]["quote"][0]["close"] if c is not None]}
    except Exception as ex: out["chartError"] = str(ex)[:80]
    try:
        s = yahoo_crumb(); mods = "price,summaryDetail,financialData,calendarEvents,earningsHistory,earningsTrend,assetProfile,defaultKeyStatistics,earnings,incomeStatementHistory"
        out["qs"] = json.loads(s["op"].open(urllib.request.Request(f"https://query1.finance.yahoo.com/v10/finance/quoteSummary/{q}?modules={mods}&crumb={urllib.parse.quote(s['crumb'])}", headers={"User-Agent": "NewsTerminal/1.0"}), timeout=20).read())
    except Exception as ex: out["qsError"] = str(ex)[:80]
    return out

FIGI_EX = {"PA": "FP", "DE": "GY", "F": "GF", "AS": "NA", "MI": "IM", "MC": "SM", "BR": "BB", "L": "LN", "SW": "SE", "ST": "SS", "CO": "DC", "HE": "FH", "OL": "NO", "LS": "PL", "VI": "AV", "IR": "ID"}
FIGI = {}
def figi_name(sym):
    """Nom officiel d'une action à partir de son symbole (OpenFIGI, gratuit, sans clé)."""
    if sym in FIGI: return FIGI[sym]
    t, _, ex = sym.partition(".")
    body = json.dumps([{"idType": "TICKER", "idValue": t, "exchCode": FIGI_EX.get(ex, ex)}]).encode()
    r = json.loads(urllib.request.urlopen(urllib.request.Request("https://api.openfigi.com/v3/mapping", body, {"Content-Type": "application/json", "User-Agent": "NewsTerminal/1.0"}), timeout=15).read())
    d = (r[0].get("data") or [{}])[0] if r else {}
    FIGI[sym] = d.get("name"); return FIGI[sym]

# ---- Comptes officiels ESEF (filings.xbrl.org) : toutes les sociétés cotées de l'UE ----
ESEF_C = {"Revenue": "rev", "RevenueFromContractsWithCustomers": "rev", "ProfitLoss": "ni", "CashAndCashEquivalents": "cash", "Equity": "eq", "CurrentAssets": "ca", "CurrentLiabilities": "cl",
          "Borrowings": "b", "CurrentBorrowings": "cb", "NoncurrentBorrowings": "nb", "ShorttermBorrowings": "sb", "LongtermBorrowings": "lb",
          "CurrentPortionOfLongtermBorrowings": "cpl", "LeaseLiabilities": "l", "CurrentLeaseLiabilities": "cll", "NoncurrentLeaseLiabilities": "nll"}
def esef_facts(url):
    import datetime as _dt
    d = json.loads(urllib.request.urlopen(urllib.request.Request(url, headers={"User-Agent": "NewsTerminal/1.0"}), timeout=90).read())
    out = {}; cur = None
    for f in (d.get("facts") or {}).values():
        dm = f.get("dimensions") or {}; c = str(dm.get("concept", ""))
        if not c.startswith("ifrs-full:") or set(dm) - {"concept", "entity", "period", "unit"}: continue
        k = ESEF_C.get(c[10:]); u = str(dm.get("unit", ""))
        if not k or not u.startswith("iso4217:"): continue
        per = str(dm.get("period", "")); end = per.split("/")[-1][:10]
        if "/" in per:
            st = per.split("/")[0][:10]
            if not (330 <= (_dt.date.fromisoformat(end) - _dt.date.fromisoformat(st)).days <= 400): continue   # exercice de 12 mois
        y = str((_dt.date.fromisoformat(end) - _dt.timedelta(days=1)).year) if per.endswith("T00:00:00") else end[:4]
        try: v = float(f.get("value"))
        except (TypeError, ValueError): continue
        out.setdefault(y, {})[k] = v; cur = u[8:]
    return out, cur
ESEF = {}
def esef(lei):
    c = ESEF.get(lei)
    if c and time.time() - c[0] < 24 * 3600: return c[1]
    fl = json.loads(urllib.request.urlopen(f"https://filings.xbrl.org/api/entities/{lei}/filings", timeout=30).read())["data"]
    fl.sort(key=lambda x: (x["attributes"].get("period_end") or "", x["attributes"].get("date_added") or ""), reverse=True)
    years, cur = {}, None
    for x in fl[:2]:
        if years: break   # le dernier rapport contient déjà 2 années
        try:
            f, cu = esef_facts("https://filings.xbrl.org" + x["attributes"]["json_url"]); cur = cur or cu
            for y, v in f.items(): years.setdefault(y, {}).update({k: w for k, w in v.items() if k not in years.get(y, {})})
        except Exception: pass
    ys = sorted(years, reverse=True)[:4]
    def debt(v):
        if "b" in v: return v["b"]
        if "cb" in v or "nb" in v: return v.get("cb", 0) + v.get("nb", 0)
        if "sb" in v or "lb" in v: return v.get("sb", 0) + v.get("lb", 0) + v.get("cpl", 0)
        return None
    def lease(v): return v.get("l") if "l" in v else (v.get("cll", 0) + v.get("nll", 0)) if ("cll" in v or "nll" in v) else None
    out = {"src": "esef", "lei": lei, "cur": cur, "dates": ys, **{k: [years[y].get(k) for y in ys] for k in ("rev", "ni", "cash", "eq", "ca", "cl")},
           "debt": [debt(years[y]) for y in ys], "lease": [lease(years[y]) for y in ys]}
    ESEF[lei] = (time.time(), out); return out

COMPANY = {}
# actions américaines à plusieurs classes (BRK.B, BF-B) ; .L Londres, .V, .F, .T… restent des places étrangères
US_CLASS = re.compile(r"^[A-Z]{1,5}[.\-/](?![LVFTISZ]$)[A-Z]$")
def company(sym):
    """Fiche société : cours, chiffres clés, bilan, prochains résultats, historique (Nasdaq)."""
    c = COMPANY.get(sym)
    if c and time.time() - c[0] < 3 * 3600: return c[1]
    if US_CLASS.match(sym): sym = sym.replace("-", ".").replace("/", ".")   # BRK.B, BF-B : action US à classes → Nasdaq
    elif "." in sym or "-" in sym:   # action cotée hors des États-Unis (ex : RMS.PA, SAP.DE) : Yahoo Finance
        out = yahoo_company(sym)
        if "chart" in out or "qs" in out: COMPANY[sym] = (time.time(), out)
        return out
    from concurrent.futures import ThreadPoolExecutor
    q = urllib.parse.quote(sym)
    urls = {"info": f"quote/{q}/info?assetclass=stocks", "summary": f"quote/{q}/summary?assetclass=stocks", "profile": f"company/{q}/company-profile",
            "fin": f"company/{q}/financials?frequency=1", "fin2": f"company/{q}/financials?frequency=2", "surprise": f"company/{q}/earnings-surprise", "edate": f"analyst/{q}/earnings-date", "forecast": f"analyst/{q}/earnings-forecast"}
    def get(item):
        k, u = item
        try:
            r = urllib.request.Request("https://api.nasdaq.com/api/" + u, headers={"User-Agent": "NewsTerminal/1.0", "Accept": "application/json"})
            return k, json.loads(urllib.request.urlopen(r, timeout=20).read()).get("data")
        except Exception as ex: return k, {"error": str(ex)[:80]}
    with ThreadPoolExecutor(6) as ex: out = dict(ex.map(get, urls.items()))
    try: out["hist"] = earnings_history(sym)
    except Exception: out["hist"] = []
    COMPANY[sym] = (time.time(), out); return out

# ---- Sentiment des particuliers : Stocktwits, Fear & Greed crypto, positions Binance, tendances CoinGecko ----
ST_MAP = {"BTC-USD": "BTC.X", "ETH-USD": "ETH.X", "SOL-USD": "SOL.X", "XRP-USD": "XRP.X", "GC=F": "XAUUSD", "XAUUSD=X": "XAUUSD", "^IXIC": "QQQ", "NQ=F": "QQQ",
          "^NDX": "QQQ", "^GSPC": "SPY", "ES=F": "SPY", "EURUSD=X": "EURUSD", "GBPUSD=X": "GBPUSD", "CL=F": "USO", "SI=F": "SLV"}
RETAIL = {}
def _getj(u, t=15):
    return json.loads(urllib.request.urlopen(urllib.request.Request(u, headers={"User-Agent": "NewsTerminal/1.0", "Accept": "application/json"}), timeout=t).read())
# ---- Variations du jour d'un panier d'actifs (humeur des marchés : actions mondiales, forex, crypto) ----
SPARK = {}
def spark(syms):
    k = ",".join(syms); c = SPARK.get(k)
    if c and time.time() - c[0] < 240: return c[1]
    out = {}
    for i in range(0, len(syms), 20):
        try:
            d = _getj("https://query1.finance.yahoo.com/v7/finance/spark?range=1d&interval=1d&symbols=" + urllib.parse.quote(",".join(syms[i:i + 20])))
            for r in (d.get("spark") or {}).get("result") or []:
                m = ((r.get("response") or [{}])[0] or {}).get("meta") or {}
                if m.get("regularMarketPrice") is not None and m.get("chartPreviousClose"):
                    out[r["symbol"]] = {"px": m["regularMarketPrice"], "p": round((m["regularMarketPrice"] / m["chartPreviousClose"] - 1) * 100, 3)}
        except Exception: pass
    SPARK[k] = (time.time(), out); return out

# ---- Chaînes Telegram publiques (page web t.me/s/<chaîne>, aucune connexion à un compte) ----
TG = {}
def tg(chs):
    out = {}
    for ch in chs:
        c = TG.get(ch)
        if c and time.time() - c[0] < 120: out[ch] = c[1]; continue
        try:
            r = urllib.request.Request("https://t.me/s/" + ch, headers={"User-Agent": "NewsTerminal/1.0"})
            v = urllib.request.urlopen(r, timeout=15).read().decode("utf-8", "replace")[-400000:]
        except Exception as ex: v = {"error": str(ex)[:80]}
        TG[ch] = (time.time(), v); out[ch] = v
    return out

def retail(syms):
    k = ",".join(sorted(syms)); c = RETAIL.get(k)
    if c and time.time() - c[0] < 1800: return c[1]
    out = {"assets": {}, "fng": None, "trending": []}
    for s in syms:
        a = {}; st = ST_MAP.get(s)
        if st:
            try:
                d = _getj(f"https://api.stocktwits.com/api/2/streams/symbol/{st}.json"); m = d.get("messages", [])
                for _ in range(19):   # toutes les dernières 24 h, jusqu'à 600 messages (20 pages de 30, limite de l'API publique)
                    cu = d.get("cursor") or {}
                    if not cu.get("more") or not cu.get("max") or not m: break
                    if calendar.timegm(time.strptime(m[-1]["created_at"], "%Y-%m-%dT%H:%M:%SZ")) < time.time() - 86400: break
                    d2 = _getj(f"https://api.stocktwits.com/api/2/streams/symbol/{st}.json?max={cu['max']}"); m += d2.get("messages", []); d["cursor"] = d2.get("cursor")
                se = [((x.get("entities") or {}).get("sentiment") or {}).get("basic") for x in m]
                ts = [calendar.timegm(time.strptime(x["created_at"], "%Y-%m-%dT%H:%M:%SZ")) for x in m if x.get("created_at")]
                a["st"] = {"sym": st, "bull": se.count("Bullish"), "bear": se.count("Bearish"), "n": len(m), "tagged": se.count("Bullish") + se.count("Bearish"), "watch": (d.get("symbol") or {}).get("watchlist_count"),
                           "perh": round(len(ts) / max(0.25, (max(ts) - min(ts)) / 3600), 1) if len(ts) > 1 else None, "last": max(ts) if ts else None}
            except Exception as ex: a["st"] = {"error": str(ex)[:80]}
        if re.match(r"^[A-Z0-9]{2,10}-USD$", s):
            p = s.replace("-USD", "USDT")
            try:
                r = _getj(f"https://fapi.binance.com/futures/data/globalLongShortAccountRatio?symbol={p}&period=1h&limit=2")
                f = _getj(f"https://fapi.binance.com/fapi/v1/premiumIndex?symbol={p}")
                a["bn"] = {"long": round(float(r[-1]["longAccount"]) * 100, 1), "prev": round(float(r[0]["longAccount"]) * 100, 1), "funding": round(float(f["lastFundingRate"]) * 100, 4)}
            except Exception as ex: a["bn"] = {"error": str(ex)[:80]}
        out["assets"][s] = a
    try:
        d = _getj("https://api.alternative.me/fng/?limit=2")["data"]
        out["fng"] = {"v": int(d[0]["value"]), "label": d[0]["value_classification"], "prev": int(d[1]["value"])}
    except Exception: pass
    try: out["trending"] = [c["item"]["symbol"].upper() for c in _getj("https://api.coingecko.com/api/v3/search/trending").get("coins", [])][:15]
    except Exception: pass
    out["ts"] = time.time(); RETAIL[k] = (time.time(), out); return out

OHLC = {}
def tidy(rows, tf):
    """Une bougie par jour (UTC) ou par semaine (lundi) : Yahoo ajoute une mini-bougie « en cours » qui faussait les pivots."""
    m = {}
    for t, o, hi, lo, cl in rows:
        k = t if tf in ("1h", "1hL") else (t + 6 * 3600 + 3 * 86400) // (7 * 86400) if tf == "1wk" else t // 86400
        if k not in m: m[k] = [t, o, hi, lo, cl]
        else: x = m[k]; x[2] = max(x[2], hi); x[3] = min(x[3], lo); x[4] = cl
    return [m[k] for k in sorted(m)]

def binance(sym, tf):
    """Crypto : bougies Binance (cotation continue, sans trous). None si indisponible."""
    mm = re.match(r"^([A-Z0-9]{2,10})-USD$", sym)
    if not mm: return None
    iv = {"1h": "1h&limit=240", "1hL": "1h&limit=1000", "1wk": "1w&limit=110"}.get(tf, "1d&limit=92")
    try:
        k = json.loads(urllib.request.urlopen(urllib.request.Request(f"https://data-api.binance.vision/api/v3/klines?symbol={mm.group(1)}USDT&interval={iv}", headers={"User-Agent": "NewsTerminal/1.0"}), timeout=12).read())
        rows = [[x[0] // 1000, float(x[1]), float(x[2]), float(x[3]), float(x[4])] for x in k]
        return {"sym": sym, "cur": "USD", "price": rows[-1][4], "src": "Binance", "rows": rows} if len(rows) >= 3 else None
    except Exception: return None

# ---- OANDA (compte démo gratuit) : or au comptant, forex, indices CFD ; journées coupées à 17 h New York ----
OANDA_INST = {"GC=F": "XAU_USD", "XAUUSD=X": "XAU_USD", "SI=F": "XAG_USD", "XAGUSD=X": "XAG_USD", "EURUSD=X": "EUR_USD", "GBPUSD=X": "GBP_USD", "JPY=X": "USD_JPY",
              "CHF=X": "USD_CHF", "AUDUSD=X": "AUD_USD", "NZDUSD=X": "NZD_USD", "CAD=X": "USD_CAD", "EURCHF=X": "EUR_CHF", "^IXIC": "NAS100_USD", "^NDX": "NAS100_USD",
              "NQ=F": "NAS100_USD", "^GSPC": "SPX500_USD", "ES=F": "SPX500_USD", "^DJI": "US30_USD", "YM=F": "US30_USD", "^GDAXI": "DE30_EUR", "CL=F": "WTICO_USD", "BZ=F": "BCO_USD"}
OANDA_FILE = os.path.join(os.path.expanduser("~"), ".newsterminal_oanda")
def oanda_tok():
    t = os.environ.get("OANDA_TOKEN", "")
    if not t and os.path.exists(OANDA_FILE):
        try: t = open(OANDA_FILE).read().strip()
        except Exception: t = ""
    return t
def oanda_get(inst, q):
    r = urllib.request.Request(f"https://api-fxpractice.oanda.com/v3/instruments/{inst}/candles?price=M&dailyAlignment=17&alignmentTimezone=America%2FNew_York&weeklyAlignment=Monday&{q}",
                               headers={"Authorization": "Bearer " + oanda_tok(), "Accept-Datetime-Format": "UNIX", "User-Agent": "NewsTerminal/1.0"})
    return json.loads(urllib.request.urlopen(r, timeout=20).read())["candles"]
def oanda_ohlc(sym, tf):
    inst = OANDA_INST.get(sym)
    if not inst or not oanda_tok(): return None
    q = {"1hL": "granularity=H1&count=1500", "1h": "granularity=H1&count=240", "1wk": "granularity=W&count=110"}.get(tf, "granularity=D&count=400")
    sh = 7 * 3600 if tf in ("1d", "1wk") else 0   # journalier / hebdo : temps = jour de trading (ouverture 17 h NY + 7 h)
    k = oanda_get(inst, q)
    rows = [[int(float(x["time"])) + sh, float(x["mid"]["o"]), float(x["mid"]["h"]), float(x["mid"]["l"]), float(x["mid"]["c"])] for x in k]
    return {"sym": sym, "cur": "USD", "price": rows[-1][4], "src": "OANDA " + inst, "rows": rows, "lastComplete": bool(k[-1].get("complete"))} if len(rows) >= 3 else None
def oanda_quote(sym, name):
    inst = OANDA_INST.get(sym)
    if not inst or not oanda_tok(): return None
    d = oanda_get(inst, "granularity=D&count=2"); m5 = oanda_get(inst, "granularity=M5&count=78")
    sp = [float(x["mid"]["c"]) for x in m5]
    return {"sym": sym, "name": name, "price": sp[-1] if sp else float(d[-1]["mid"]["c"]), "prev": float(d[-2]["mid"]["c"]) if len(d) > 1 else None,
            "time": int(time.time()), "cur": "USD", "spark": sp, "src": "OANDA"}

def ohlc(sym, tf="1d"):
    """Bougies : journalières (3 mois) ou H1 (10 jours) — ouverture, plus haut, plus bas, clôture."""
    k = sym + "|" + tf; c = OHLC.get(k)
    if c and time.time() - c[0] < (1800 if tf in ("1d", "1hL") else 600): return c[1]
    try: out = oanda_ohlc(sym, tf)
    except Exception: out = None
    out = out or binance(sym, tf)
    if out: out["rows"] = tidy(out["rows"], tf); OHLC[k] = (time.time(), out); return out
    rng = {"1d": "3mo&interval=1d", "1h": "10d&interval=60m", "1hL": "3mo&interval=60m", "1wk": "2y&interval=1wk"}.get(tf, "3mo&interval=1d")
    u = "https://query1.finance.yahoo.com/v8/finance/chart/" + urllib.parse.quote(sym) + "?range=" + rng
    r = json.loads(urllib.request.urlopen(urllib.request.Request(u, headers={"User-Agent": "NewsTerminal/1.0"}), timeout=15).read())["chart"]["result"][0]
    q = r["indicators"]["quote"][0]
    rows = [[t, o, hi, lo, cl] for t, o, hi, lo, cl in zip(r["timestamp"], q["open"], q["high"], q["low"], q["close"]) if None not in (o, hi, lo, cl)]
    out = {"sym": sym, "cur": r["meta"].get("currency"), "price": r["meta"].get("regularMarketPrice"), "rows": tidy(rows, tf)}
    OHLC[k] = (time.time(), out); return out

def yahoo_search(q):
    u = "https://query1.finance.yahoo.com/v1/finance/search?quotesCount=8&newsCount=0&q=" + urllib.parse.quote(q)
    d = json.loads(urllib.request.urlopen(urllib.request.Request(u, headers={"User-Agent": "NewsTerminal/1.0"}), timeout=10).read())
    return [{"sym": x.get("symbol"), "name": x.get("shortname") or x.get("longname") or x.get("symbol"), "ex": x.get("exchDisp", ""), "type": x.get("quoteType", "")}
            for x in d.get("quotes", []) if x.get("symbol")]

# ---- Traduction gratuite (Google Translate, avec cache) ----
TR = {}
def translate(q, tl="fr"):
    k = tl + "|" + q
    if k in TR: return TR[k]
    u = "https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=" + tl + "&dt=t&q=" + urllib.parse.quote(q)
    d = json.loads(urllib.request.urlopen(urllib.request.Request(u, headers={"User-Agent": "NewsTerminal/1.0"}), timeout=10).read())
    out = {"text": "".join(p[0] for p in d[0] if p and p[0]), "src": d[2] if len(d) > 2 else ""}
    if len(TR) > 5000: TR.clear()
    TR[k] = out; return out

# ---- Relais IA (fournisseurs gratuits compatibles OpenAI) ----
AI_HOSTS = ("https://api.groq.com/", "https://api.mistral.ai/", "https://generativelanguage.googleapis.com/", "https://openrouter.ai/", "https://api.x.ai/")
def ai_call(req):
    url = req.get("url", "")
    if not url.startswith(AI_HOSTS): raise ValueError("fournisseur non autorisé")
    body = json.dumps({"model": req["model"], "messages": req["messages"], "temperature": 0.2}).encode()
    r = urllib.request.Request(url, body, {"Content-Type": "application/json", "Authorization": "Bearer " + req["key"], "User-Agent": "NewsTerminal/1.0"})
    try:
        d = json.loads(urllib.request.urlopen(r, timeout=60).read())
    except urllib.error.HTTPError as ex:
        raise ValueError(f"HTTP {ex.code} : {ex.read().decode('utf-8', 'replace')[:200]}")
    return d["choices"][0]["message"]["content"]

def ai_models(req):
    """Liste des modèles disponibles chez le fournisseur (API compatible OpenAI : GET …/models)."""
    url = req.get("url", "")
    if not url.startswith(AI_HOSTS): raise ValueError("fournisseur non autorisé")
    base = url.rsplit("/chat/completions", 1)[0] + "/models"
    r = urllib.request.Request(base, headers={"Authorization": "Bearer " + req["key"], "User-Agent": "NewsTerminal/1.0"})
    d = json.loads(urllib.request.urlopen(r, timeout=20).read())
    return [m.get("id") for m in d.get("data", []) if m.get("id")]

REFRESH = threading.Event()
def poller():
    nxt = {f[1]: 0 for f in FEEDS}; first = {f[1]: True for f in FEEDS}
    with ThreadPoolExecutor(16) as ex:
        while True:
            now = time.time()
            if REFRESH.is_set():   # « tirer pour actualiser » : toutes les sources tout de suite
                REFRESH.clear(); nxt = {k: 0 for k in nxt}
            for f in FEEDS:
                if now >= nxt[f[1]]:
                    nxt[f[1]] = now + f[3]
                    fl = first[f[1]]; first[f[1]] = False
                    ex.submit(poll, f, fl)
            time.sleep(1)

HERE = os.path.dirname(os.path.abspath(__file__))
STATIC = {"/": ("index.html", "text/html; charset=utf-8"), "/manifest.json": ("manifest.json", "application/manifest+json"),
          "/sw.js": ("sw.js", "text/javascript"), "/icon.svg": ("icon.svg", "image/svg+xml")}

class H(BaseHTTPRequestHandler):
    def log_message(self, *a): pass
    def send(self, code, body, ctype):
        self.send_response(code); self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body))); self.end_headers(); self.wfile.write(body)
    def authed(self):
        if not PASSWORD or self.path in ("/manifest.json", "/icon.svg", "/sw.js"): return True
        h = self.headers.get("Authorization", "")
        try: ok = h.startswith("Basic ") and base64.b64decode(h[6:]).decode().split(":", 1)[1] == PASSWORD
        except Exception: ok = False
        if not ok:
            self.send_response(401); self.send_header("WWW-Authenticate", 'Basic realm="News Terminal"')
            self.send_header("Content-Length", "0"); self.end_headers()
        return ok
    def do_POST(self):
        if not self.authed(): return
        if self.path == "/api/secret":  # jeton OANDA (version Mac : fichier privé dans le dossier personnel)
            try:
                req = json.loads(self.rfile.read(int(self.headers.get("Content-Length", 0))))
                if req.get("name") == "oanda":
                    v = str(req.get("value") or "").strip()
                    if v:
                        with open(OANDA_FILE, "w") as f: f.write(v)
                        os.chmod(OANDA_FILE, 0o600)
                    elif os.path.exists(OANDA_FILE): os.remove(OANDA_FILE)
                    OHLC.clear(); PRICES.clear()
                self.send(200, json.dumps({"ok": True, "has": bool(oanda_tok())}).encode(), "application/json")
            except Exception as ex: self.send(400, json.dumps({"error": str(ex)}).encode(), "application/json")
            return
        if self.path == "/api/quotes":  # liste d'actifs choisie dans les Réglages
            try:
                req = json.loads(self.rfile.read(int(self.headers.get("Content-Length", 0))))
                q = [(str(x["sym"])[:20], str(x.get("name") or x["sym"])[:40]) for x in req.get("quotes", [])][:40]
                if q: QUOTES[:] = q
                out = {"ok": True}
            except Exception as ex: out = {"error": str(ex)[:100]}
            self.send(200, json.dumps(out).encode(), "application/json")
        elif self.path == "/api/aimodels":
            try:
                req = json.loads(self.rfile.read(int(self.headers.get("Content-Length", 0))))
                out = {"models": ai_models(req)}
            except Exception as ex: out = {"error": str(ex)[:300]}
            self.send(200, json.dumps(out).encode(), "application/json")
        elif self.path == "/api/ai":
            try:
                req = json.loads(self.rfile.read(int(self.headers.get("Content-Length", 0))))
                out = {"text": ai_call(req)}
            except Exception as ex: out = {"error": str(ex)[:300]}
            self.send(200, json.dumps(out).encode(), "application/json")
        else: self.send(404, b"", "text/plain")
    def do_GET(self):
        if not self.authed(): return
        if self.path in STATIC:
            f, ct = STATIC[self.path]
            self.send(200, open(os.path.join(HERE, f), "rb").read(), ct)
        elif self.path == "/api/news":
            with lock:
                rows = db.execute("""SELECT id,ts,seen,src,cat,title,link,score,feed FROM (SELECT *, ROW_NUMBER() OVER (PARTITION BY cat ORDER BY ts DESC) rn FROM news)
                                     WHERE rn <= 150 ORDER BY ts DESC""").fetchall()  # 150 max par catégorie
            keys = ["id", "ts", "seen", "src", "cat", "title", "link", "score", "feed"]
            out = [dict(zip(keys, r)) for r in rows]
            for o in out: o["score"] = score(o["title"]); o["why"] = why(o["title"])
            self.send(200, json.dumps(out).encode(), "application/json")
        elif self.path == "/api/stats":
            try: body = open(os.path.join(HERE, "stats.json"), "rb").read()
            except Exception: body = b"{}"
            self.send(200, body, "application/json")
        elif self.path == "/api/prices":
            self.send(200, json.dumps(PRICES).encode(), "application/json")
        elif self.path.startswith("/api/esef?"):
            q = urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query).get("lei", [""])[0][:20]
            try: out = esef(q)
            except Exception as ex: out = {"error": str(ex)[:100]}
            self.send(200, json.dumps(out).encode(), "application/json")
        elif self.path.startswith("/api/figi?"):
            q = urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query).get("sym", [""])[0][:20]
            try: out = {"name": figi_name(q)}
            except Exception as ex: out = {"error": str(ex)[:100]}
            self.send(200, json.dumps(out).encode(), "application/json")
        elif self.path == "/api/esef_entities":
            self.send(200, open(os.path.join(HERE, "esef_entities.json"), "rb").read(), "application/json")
        elif self.path.startswith("/api/company?"):
            q = urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query).get("sym", [""])[0][:15]
            try: out = company(q)
            except Exception as ex: out = {"error": str(ex)[:100]}
            self.send(200, json.dumps(out).encode(), "application/json")
        elif self.path.startswith("/api/ehist?"):
            q = urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query).get("sym", [""])[0][:15]
            try: out = {"rows": earnings_history(q)}
            except Exception as ex: out = {"error": str(ex)[:100]}
            self.send(200, json.dumps(out).encode(), "application/json")
        elif self.path.startswith("/api/ohlc?"):
            qq = urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query); q = qq.get("sym", [""])[0][:20]
            tf = qq.get("tf", ["1d"])[0]
            try: out = ohlc(q, tf if tf in ("1h", "1wk", "1hL") else "1d")
            except Exception as ex: out = {"error": str(ex)[:100]}
            self.send(200, json.dumps(out).encode(), "application/json")
        elif self.path.startswith("/api/search?"):
            q = urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query).get("q", [""])[0][:60]
            try: out = {"results": yahoo_search(q)}
            except Exception as ex: out = {"error": str(ex)[:100]}
            self.send(200, json.dumps(out).encode(), "application/json")
        elif self.path.startswith("/api/tr?"):
            q = urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query)
            try: out = translate(q.get("q", [""])[0][:500], q.get("tl", ["fr"])[0])
            except Exception as ex: out = {"error": str(ex)[:100]}
            self.send(200, json.dumps(out).encode(), "application/json")
        elif self.path == "/api/calendar":
            self.send(200, json.dumps({**CAL, "ahead": AHEAD}).encode(), "application/json")
        elif self.path.startswith("/api/retail?"):
            syms = [x for x in urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query).get("syms", [""])[0].split(",") if x][:10]
            self.send(200, json.dumps(retail(syms)).encode(), "application/json")
        elif self.path.startswith("/api/spark?"):
            syms = [x for x in urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query).get("syms", [""])[0].split(",") if re.fullmatch(r"[\w.^=\-]{1,20}", x)][:80]
            self.send(200, json.dumps(spark(syms)).encode(), "application/json")
        elif self.path.startswith("/api/tg?"):
            chs = [x for x in urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query).get("ch", [""])[0].split(",") if re.fullmatch(r"[A-Za-z0-9_]{4,40}", x)][:10]
            self.send(200, json.dumps(tg(chs)).encode(), "application/json")
        elif self.path == "/api/refresh":
            REFRESH.set(); CAL["ts"] = 0
            self.send(200, b'{"ok":true}', "application/json")
        elif self.path == "/api/status":
            out = [{"name": f[0], "cat": f[2], "lang": LANG.get(f[0], "en"), "ok": state.get(f[1], {}).get("err") is None and "last" in state.get(f[1], {}),
                    "err": state.get(f[1], {}).get("err")} for f in FEEDS]
            self.send(200, json.dumps(out).encode(), "application/json")
        elif self.path == "/stream":
            self.send_response(200); self.send_header("Content-Type", "text/event-stream")
            self.send_header("Cache-Control", "no-cache"); self.end_headers()
            q = queue.Queue(); clients.append(q)
            try:
                while True:
                    try: msg = f"data: {json.dumps(q.get(timeout=15))}\n\n"
                    except queue.Empty: msg = ": ping\n\n"
                    self.wfile.write(msg.encode()); self.wfile.flush()
            except Exception: pass
            finally: clients.remove(q)
        else: self.send(404, b"", "text/plain")

if __name__ == "__main__":
    threading.Thread(target=poller, daemon=True).start()
    threading.Thread(target=report, daemon=True).start()
    threading.Thread(target=cal_poller, daemon=True).start()
    threading.Thread(target=price_poller, daemon=True).start()
    threading.Thread(target=ahead_poller, daemon=True).start()
    print(f"Terminal: http://localhost:{PORT}")
    ThreadingHTTPServer(("0.0.0.0", PORT), H).serve_forever()
