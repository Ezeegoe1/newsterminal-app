#!/bin/bash
cd "$(dirname "$0")"
pip3 install -q -r requirements.txt
(sleep 4 && open http://localhost:8765) &
python3 server.py
